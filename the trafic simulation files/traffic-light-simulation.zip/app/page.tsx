import TrafficSimulation from "@/components/traffic-simulation"

export default function Home() {
  return (
    <main className="flex min-h-screen flex-col items-center justify-between p-4 md:p-8">
      <div className="w-full max-w-6xl space-y-8">
        <h1 className="text-3xl font-bold text-center">Traffic Light Timing Simulation</h1>
        <p className="text-center text-gray-600 max-w-3xl mx-auto">
          Compare adaptive traffic light timing with 20-second static timing under gradually changing traffic
          conditions.
        </p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="border rounded-lg p-4 bg-white shadow-md">
            <h2 className="text-xl font-semibold mb-4 text-center">Adaptive Timing</h2>
            <div className="aspect-square w-full">
              <TrafficSimulation adaptive={true} />
            </div>
            <div className="mt-4 p-3 bg-gray-50 rounded-md text-sm">
              <p className="font-medium">Formula:</p>
              <p className="font-mono text-xs mt-1">
                Tg = Tb + k(n_cars - n_avr) if n_cars &lt; 2·n_avr
                <br />
                Tg = 0.7·[Tb + k(n_cars - n_avr)] if n_cars ≥ 2·n_avr
              </p>
            </div>
          </div>

          <div className="border rounded-lg p-4 bg-white shadow-md">
            <h2 className="text-xl font-semibold mb-4 text-center">Static Timing (20 seconds)</h2>
            <div className="aspect-square w-full">
              <TrafficSimulation adaptive={false} />
            </div>
            <div className="mt-4 p-3 bg-gray-50 rounded-md text-sm">
              <p>Fixed green light duration of 20 seconds per direction, regardless of traffic volume.</p>
            </div>
          </div>
        </div>

        <div className="border rounded-lg p-4 bg-white shadow-md">
          <h2 className="text-xl font-semibold mb-4">Gradual Traffic Pattern Simulation</h2>
          <p className="mb-2">
            This simulation features slowly changing traffic patterns with congestion levels ranging from 10% to 70%,
            with complete pattern cycles taking approximately 15 seconds:
          </p>

          <div className="grid md:grid-cols-2 gap-6 mt-4">
            <div className="space-y-2">
              <h3 className="font-medium">Traffic Pattern Features:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>
                  <strong>Slow Transitions:</strong> Traffic patterns change gradually over 10-20 seconds
                </li>
                <li>
                  <strong>Moderate Congestion Range:</strong> Traffic levels vary between 10% and 70%
                </li>
                <li>
                  <strong>Phase Difference:</strong> N/S and E/W traffic patterns are 120° out of phase
                </li>
                <li>
                  <strong>Occasional Bursts:</strong> Periodic traffic bursts test system responsiveness
                </li>
                <li>
                  <strong>Realistic Patterns:</strong> Traffic flow mimics real-world conditions with natural variations
                </li>
              </ul>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">Timing Comparison:</h3>
              <ul className="list-disc pl-5 space-y-1">
                <li>
                  <strong>Adaptive System:</strong> Dynamically adjusts green time based on waiting vehicles using the
                  formula:
                  <div className="font-mono text-xs mt-1 ml-2">
                    Tg = Tb + k(n_cars - n_avr) if n_cars &lt; 2·n_avr
                    <br />
                    Tg = 0.7·[Tb + k(n_cars - n_avr)] if n_cars ≥ 2·n_avr
                  </div>
                </li>
                <li>
                  <strong>Static System:</strong> Fixed 20-second green time per direction regardless of traffic volume
                </li>
                <li>Both simulations receive identical traffic patterns for fair comparison</li>
              </ul>
            </div>
          </div>

          <div className="mt-6 p-4 bg-yellow-50 rounded-md">
            <h3 className="font-medium mb-2">Key Observations:</h3>
            <p>With gradually changing congestion levels (10-70%) over longer periods, you can observe:</p>
            <ul className="list-disc pl-5 mt-2 space-y-1">
              <li>
                <strong>Long-term efficiency:</strong> How each system performs over extended traffic cycles
              </li>
              <li>
                <strong>Adaptation to slow changes:</strong> How the adaptive system gradually adjusts to changing
                traffic patterns
              </li>
              <li>
                <strong>Response to traffic bursts:</strong> How each system handles sudden, unexpected traffic
                increases
              </li>
              <li>
                <strong>Balanced traffic handling:</strong> How each system manages traffic when N/S and E/W congestion
                levels differ
              </li>
              <li>
                <strong>Overall performance metrics:</strong> Compare total vehicles passed, average wait times, and
                efficiency ratios
              </li>
            </ul>
          </div>
        </div>
      </div>
    </main>
  )
}
