export default function FormulaDisplay() {
  return (
    <div className="p-4 bg-white rounded-lg shadow-md">
      <h2 className="text-xl font-semibold mb-4">Adaptive Traffic Light Timing Formula</h2>
      <div className="p-4 bg-gray-50 rounded-md font-mono text-sm">
        <p>T_g = T_b + k(n_cars - n_avr), if n_cars &lt; 2 · n_avr</p>
        <p>T_g = 0.7 · [T_b + k(n_cars - n_avr)], if n_cars ≥ 2 · n_avr</p>
      </div>

      <div className="mt-4 space-y-2">
        <p>
          <strong>T_g:</strong> Final green light duration based on real-time traffic
        </p>
        <p>
          <strong>T_b:</strong> Minimum green light time required for safe crossing
        </p>
        <p>
          <strong>k:</strong> Time required for a single vehicle to pass through the intersection
        </p>
        <p>
          <strong>n_cars:</strong> Number of vehicles currently detected
        </p>
        <p>
          <strong>n_avr:</strong> Average number of vehicles typically expected on this road
        </p>
      </div>

      <div className="mt-4 p-3 bg-yellow-50 rounded-md text-sm">
        <p>
          <strong>Note:</strong> If the detected number of vehicles is twice or more than the average expected traffic,
          only 70% of the calculated time is used. This prevents excessive delays on other roads and promotes fair
          distribution of green time across all directions.
        </p>
      </div>
    </div>
  )
}
