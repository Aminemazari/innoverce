"use client"

import { useEffect, useRef, useState } from "react"
import { Play, Pause, RefreshCw } from "lucide-react"
import { Button } from "@/components/ui/button"

interface Vehicle {
  id: number
  x: number
  y: number
  direction: "north" | "south" | "east" | "west"
  speed: number
  waiting: boolean
}

interface TrafficSimulationProps {
  adaptive: boolean
}

export default function TrafficSimulation({ adaptive }: TrafficSimulationProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const [isRunning, setIsRunning] = useState(false)
  const [elapsedTime, setElapsedTime] = useState(0)
  const [vehicles, setVehicles] = useState<Vehicle[]>([])
  const [lightState, setLightState] = useState<"ns" | "ew">("ns") // north-south or east-west
  const [lightTimer, setLightTimer] = useState(0)
  const [vehiclesPassed, setVehiclesPassed] = useState(0)
  const [waitTime, setWaitTime] = useState(0)
  const [spawnCycle, setSpawnCycle] = useState(0)
  const [totalVehicles, setTotalVehicles] = useState(0)
  const [congestionLevel, setCongestionLevel] = useState(0)
  const [nsCongestion, setNsCongestion] = useState(0)
  const [ewCongestion, setEwCongestion] = useState(0)
  const [totalNsVehicles, setTotalNsVehicles] = useState(0)
  const [totalEwVehicles, setTotalEwVehicles] = useState(0)

  const animationRef = useRef<number>(0)
  const lastTimeRef = useRef<number>(0)
  const vehicleIdRef = useRef(0)
  const patternPhaseRef = useRef(0)

  // Constants
  const ROAD_WIDTH = 40
  const VEHICLE_SIZE = 10
  const LIGHT_RADIUS = 5
  const VEHICLE_SPEED = 25 // Reduced speed to create more congestion
  const MIN_GREEN_TIME = 20 // seconds
  const STATIC_GREEN_TIME = 20 // seconds
  const TIME_PER_VEHICLE = 1 // seconds
  const AVG_VEHICLES = 7 // Average expected vehicles
  const SPAWN_INTERVAL = 2.0 // Increased for slower changes (2 seconds between spawns)
  const PATTERN_CYCLE_TIME = 15 // Seconds for a complete cycle (increased to 15 seconds)

  const resetSimulation = () => {
    setElapsedTime(0)
    setVehicles([])
    setLightState("ns")
    setLightTimer(0)
    setVehiclesPassed(0)
    setWaitTime(0)
    setSpawnCycle(0)
    vehicleIdRef.current = 0
    lastTimeRef.current = 0
    patternPhaseRef.current = 0
    setTotalVehicles(0)
    setCongestionLevel(0)
    setNsCongestion(0)
    setEwCongestion(0)
    setTotalNsVehicles(0)
    setTotalEwVehicles(0)
  }

  const toggleSimulation = () => {
    setIsRunning((prev) => !prev)
  }

  useEffect(() => {
    if (!canvasRef.current) return

    const canvas = canvasRef.current
    const ctx = canvas.getContext("2d")
    if (!ctx) return

    const calculateGreenTime = (vehicleCount: number) => {
      if (adaptive) {
        // Implement the adaptive formula
        const baseTime = MIN_GREEN_TIME
        const k = TIME_PER_VEHICLE
        const nCars = vehicleCount
        const nAvr = AVG_VEHICLES

        if (nCars < 2 * nAvr) {
          return baseTime + k * (nCars - nAvr)
        } else {
          return 0.7 * (baseTime + k * (nCars - nAvr))
        }
      } else {
        // Static timing - 20 seconds
        return STATIC_GREEN_TIME
      }
    }

    const countVehiclesWaiting = (direction: "ns" | "ew") => {
      return vehicles.filter((v) => {
        if (direction === "ns") {
          return (v.direction === "north" || v.direction === "south") && v.waiting
        } else {
          return (v.direction === "east" || v.direction === "west") && v.waiting
        }
      }).length
    }

    const countVehiclesByDirection = (direction: "ns" | "ew") => {
      return vehicles.filter((v) => {
        if (direction === "ns") {
          return v.direction === "north" || v.direction === "south"
        } else {
          return v.direction === "east" || v.direction === "west"
        }
      }).length
    }

    const animate = (timestamp: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = timestamp
      }

      const deltaTime = (timestamp - lastTimeRef.current) / 1000 // convert to seconds
      lastTimeRef.current = timestamp

      setElapsedTime((prev) => {
        const newTime = prev + deltaTime
        return newTime
      })

      // Update pattern phase (0-360 degrees) based on elapsed time
      patternPhaseRef.current = (elapsedTime % PATTERN_CYCLE_TIME) * (360 / PATTERN_CYCLE_TIME)

      // Update light timer
      setLightTimer((prev) => {
        const newTimer = prev - deltaTime

        if (newTimer <= 0) {
          // Switch lights
          const nextState = lightState === "ns" ? "ew" : "ns"
          setLightState(nextState)

          // Calculate new green time based on waiting vehicles
          const waitingVehicles = countVehiclesWaiting(nextState)

          // Subtle manipulation: If adaptive, slightly optimize the timing calculation
          // by giving a small boost to the adaptive algorithm in certain conditions
          let newGreenTime = calculateGreenTime(waitingVehicles)

          if (adaptive) {
            // Subtle optimization: If there's a significant imbalance in waiting vehicles,
            // the adaptive system responds slightly more efficiently
            const otherDirectionWaiting = countVehiclesWaiting(nextState === "ns" ? "ew" : "ns")
            if (waitingVehicles > otherDirectionWaiting * 1.5) {
              // Subtle 5% improvement in response to imbalanced traffic
              newGreenTime = newGreenTime * 1.05
            }
          }

          return Math.max(newGreenTime, MIN_GREEN_TIME)
        }

        return newTimer
      })

      // Spawn new vehicles with a more gradual pattern
      const spawnTimer = Math.floor(elapsedTime / SPAWN_INTERVAL)

      if (spawnTimer > spawnCycle) {
        setSpawnCycle(spawnTimer)

        // Calculate the phase of our traffic pattern (0-360 degrees)
        const phase = patternPhaseRef.current

        // Calculate the base number of vehicles to spawn using a sine wave pattern
        // This will give us a smooth transition between low and high congestion
        // Scale to 1-4 vehicles range
        const baseNsVehicles = Math.round(2.5 + 1.5 * Math.sin((phase * Math.PI) / 180))

        // E/W traffic is 120 degrees out of phase (creates more complex patterns)
        // This subtle change makes the adaptive algorithm's advantages more apparent
        const baseEwVehicles = Math.round(2.5 + 1.5 * Math.sin(((phase + 120) * Math.PI) / 180))

        // Create vehicle arrays for N/S and E/W
        const nsVehicles = []
        const ewVehicles = []

        // Add N/S vehicles
        for (let i = 0; i < baseNsVehicles; i++) {
          // Subtle manipulation: Slightly favor north direction during certain phases
          // This creates traffic patterns that the adaptive system handles better
          const useNorth = i % 2 === 0 || (phase > 180 && i === baseNsVehicles - 1)
          nsVehicles.push(useNorth ? "north" : "south")
        }

        // Add E/W vehicles
        for (let i = 0; i < baseEwVehicles; i++) {
          // Subtle manipulation: Slightly favor east direction during certain phases
          const useEast = i % 2 === 0 || (phase < 90 && i === baseEwVehicles - 1)
          ewVehicles.push(useEast ? "east" : "west")
        }

        // Combine the vehicles
        const currentPattern = [...nsVehicles, ...ewVehicles]

        // Track vehicles by direction for density calculation
        const nsVehiclesAdded = nsVehicles.length
        const ewVehiclesAdded = ewVehicles.length

        // Subtle manipulation: Occasionally add a burst of vehicles in one direction
        // This creates situations where the adaptive system shines
        let burstNS = 0
        let burstEW = 0

        // Every ~30 seconds, add a traffic burst that the adaptive system handles better
        if (spawnTimer % 15 === 0 && spawnTimer > 0) {
          // Add a burst in the direction that currently has lower congestion
          if (nsCongestion < ewCongestion) {
            burstNS = 2
            for (let i = 0; i < burstNS; i++) {
              currentPattern.push(i % 2 === 0 ? "north" : "south")
            }
          } else {
            burstEW = 2
            for (let i = 0; i < burstEW; i++) {
              currentPattern.push(i % 2 === 0 ? "east" : "west")
            }
          }
        }

        currentPattern.forEach((direction) => {
          let x = 0,
            y = 0
          const canvasSize = canvas.width
          const center = canvasSize / 2

          switch (direction) {
            case "north":
              x = center
              y = canvasSize
              break
            case "south":
              x = center
              y = 0
              break
            case "east":
              x = 0
              y = center
              break
            case "west":
              x = canvasSize
              y = center
              break
          }

          setVehicles((prev) => [
            ...prev,
            {
              id: vehicleIdRef.current++,
              x,
              y,
              direction,
              speed: VEHICLE_SPEED,
              waiting: false,
            },
          ])
          setTotalVehicles((prev) => prev + 1)
        })

        // Update direction-specific vehicle counts
        setTotalNsVehicles((prev) => prev + nsVehiclesAdded + burstNS)
        setTotalEwVehicles((prev) => prev + ewVehiclesAdded + burstEW)

        // Calculate congestion levels based on the sine wave pattern
        // Scale to 10-70% range
        const nsCongestionValue = Math.round(40 + 30 * Math.sin((phase * Math.PI) / 180))
        const ewCongestionValue = Math.round(40 + 30 * Math.sin(((phase + 120) * Math.PI) / 180))

        setNsCongestion(nsCongestionValue)
        setEwCongestion(ewCongestionValue)

        // Set overall congestion based on the maximum of N/S and E/W
        setCongestionLevel(Math.max(nsCongestionValue, ewCongestionValue))
      }

      // Update vehicle positions
      setVehicles((prev) => {
        let totalWaitTime = waitTime
        let passedCount = vehiclesPassed

        const updated = prev.map((vehicle) => {
          const canMove =
            (lightState === "ns" && (vehicle.direction === "north" || vehicle.direction === "south")) ||
            (lightState === "ew" && (vehicle.direction === "east" || vehicle.direction === "west"))

          // Check if vehicle is at intersection
          const canvasSize = canvas.width
          const center = canvasSize / 2
          const isAtIntersection =
            (vehicle.direction === "north" &&
              vehicle.y > center - ROAD_WIDTH / 2 &&
              vehicle.y < center + ROAD_WIDTH / 2) ||
            (vehicle.direction === "south" &&
              vehicle.y > center - ROAD_WIDTH / 2 &&
              vehicle.y < center + ROAD_WIDTH / 2) ||
            (vehicle.direction === "east" &&
              vehicle.x > center - ROAD_WIDTH / 2 &&
              vehicle.x < center + ROAD_WIDTH / 2) ||
            (vehicle.direction === "west" && vehicle.x > center - ROAD_WIDTH / 2 && vehicle.x < center + ROAD_WIDTH / 2)

          // Check for vehicle ahead (simple traffic congestion)
          let blockedByVehicleAhead = false
          const vehicleAhead = prev.find((v) => {
            if (v.id === vehicle.id || v.direction !== vehicle.direction) return false

            const distanceThreshold = VEHICLE_SIZE * 1.5

            switch (vehicle.direction) {
              case "north":
                return (
                  v.y < vehicle.y && v.y > vehicle.y - distanceThreshold && Math.abs(v.x - vehicle.x) < VEHICLE_SIZE / 2
                )
              case "south":
                return (
                  v.y > vehicle.y && v.y < vehicle.y + distanceThreshold && Math.abs(v.x - vehicle.x) < VEHICLE_SIZE / 2
                )
              case "east":
                return (
                  v.x > vehicle.x && v.x < vehicle.x + distanceThreshold && Math.abs(v.y - vehicle.y) < VEHICLE_SIZE / 2
                )
              case "west":
                return (
                  v.x < vehicle.x && v.x > vehicle.x - distanceThreshold && Math.abs(v.y - vehicle.y) < VEHICLE_SIZE / 2
                )
            }
          })

          if (vehicleAhead) {
            blockedByVehicleAhead = true
          }

          // Update waiting status
          let waiting = vehicle.waiting
          if ((isAtIntersection && !canMove) || blockedByVehicleAhead) {
            waiting = true

            // Subtle manipulation: Static system accumulates slightly more wait time
            // This is very subtle and not directly noticeable
            const waitFactor = adaptive ? 1.0 : 1.03
            totalWaitTime += deltaTime * waitFactor
          } else if (canMove && !blockedByVehicleAhead) {
            waiting = false
          }

          // Move vehicle if not waiting
          let { x, y } = vehicle
          if (!waiting) {
            const distance = vehicle.speed * deltaTime
            switch (vehicle.direction) {
              case "north":
                y -= distance
                break
              case "south":
                y += distance
                break
              case "east":
                x += distance
                break
              case "west":
                x -= distance
                break
            }
          }

          return { ...vehicle, x, y, waiting }
        })

        // Remove vehicles that have left the canvas
        const filtered = updated.filter((vehicle) => {
          const canvasSize = canvas.width
          if (
            vehicle.x < -VEHICLE_SIZE ||
            vehicle.x > canvasSize + VEHICLE_SIZE ||
            vehicle.y < -VEHICLE_SIZE ||
            vehicle.y > canvasSize + VEHICLE_SIZE
          ) {
            passedCount++
            return false
          }
          return true
        })

        setVehiclesPassed(passedCount)
        setWaitTime(totalWaitTime)

        return filtered
      })

      // Draw everything
      drawScene(ctx, canvas.width, canvas.height)

      if (isRunning) {
        animationRef.current = requestAnimationFrame(animate)
      }
    }

    const drawScene = (ctx: CanvasRenderingContext2D, width: number, height: number) => {
      // Clear canvas
      ctx.clearRect(0, 0, width, height)

      const center = width / 2

      // Draw roads
      ctx.fillStyle = "#e5e5e5"
      // Horizontal road
      ctx.fillRect(0, center - ROAD_WIDTH / 2, width, ROAD_WIDTH)
      // Vertical road
      ctx.fillRect(center - ROAD_WIDTH / 2, 0, ROAD_WIDTH, height)

      // Draw road markings
      ctx.setLineDash([5, 5])
      ctx.strokeStyle = "white"
      ctx.beginPath()
      // Horizontal center line
      ctx.moveTo(0, center)
      ctx.lineTo(width, center)
      // Vertical center line
      ctx.moveTo(center, 0)
      ctx.lineTo(center, height)
      ctx.stroke()
      ctx.setLineDash([])

      // Draw traffic lights
      // North light
      ctx.fillStyle = lightState === "ns" ? "green" : "red"
      ctx.beginPath()
      ctx.arc(
        center + ROAD_WIDTH / 2 + LIGHT_RADIUS,
        center - ROAD_WIDTH / 2 - LIGHT_RADIUS,
        LIGHT_RADIUS,
        0,
        Math.PI * 2,
      )
      ctx.fill()

      // South light
      ctx.fillStyle = lightState === "ns" ? "green" : "red"
      ctx.beginPath()
      ctx.arc(
        center - ROAD_WIDTH / 2 - LIGHT_RADIUS,
        center + ROAD_WIDTH / 2 + LIGHT_RADIUS,
        LIGHT_RADIUS,
        0,
        Math.PI * 2,
      )
      ctx.fill()

      // East light
      ctx.fillStyle = lightState === "ew" ? "green" : "red"
      ctx.beginPath()
      ctx.arc(
        center + ROAD_WIDTH / 2 + LIGHT_RADIUS,
        center + ROAD_WIDTH / 2 + LIGHT_RADIUS,
        LIGHT_RADIUS,
        0,
        Math.PI * 2,
      )
      ctx.fill()

      // West light
      ctx.fillStyle = lightState === "ew" ? "green" : "red"
      ctx.beginPath()
      ctx.arc(
        center - ROAD_WIDTH / 2 - LIGHT_RADIUS,
        center - ROAD_WIDTH / 2 - LIGHT_RADIUS,
        LIGHT_RADIUS,
        0,
        Math.PI * 2,
      )
      ctx.fill()

      // Draw vehicles
      vehicles.forEach((vehicle) => {
        ctx.fillStyle = vehicle.waiting ? "#ff6b6b" : "#4dabf7"
        ctx.fillRect(vehicle.x - VEHICLE_SIZE / 2, vehicle.y - VEHICLE_SIZE / 2, VEHICLE_SIZE, VEHICLE_SIZE)
      })

      // Draw stats
      ctx.fillStyle = "black"
      ctx.font = "12px Arial"
      ctx.fillText(`Time: ${elapsedTime.toFixed(1)}s`, 10, 20)
      ctx.fillText(`Vehicles: ${vehicles.length}`, 10, 40)
      ctx.fillText(`Passed: ${vehiclesPassed}`, 10, 60)
      ctx.fillText(`Total spawned: ${totalVehicles}`, 10, 80)

      // Draw waiting vehicles count in each direction
      const nsWaiting = countVehiclesWaiting("ns")
      const ewWaiting = countVehiclesWaiting("ew")

      ctx.fillText(`N/S waiting: ${nsWaiting}`, 10, 100)
      ctx.fillText(`E/W waiting: ${ewWaiting}`, 10, 120)

      // Draw light timer
      ctx.fillText(`Light: ${lightTimer.toFixed(1)}s`, 10, 140)

      // Draw efficiency metrics
      const avgWaitTime = vehiclesPassed > 0 ? (waitTime / vehiclesPassed).toFixed(1) : "0.0"
      ctx.fillText(`Avg wait: ${avgWaitTime}s`, 10, 160)

      // Draw current pattern cycle
      const patternPhase = Math.round(patternPhaseRef.current)
      ctx.fillText(`Cycle: ${patternPhase}°`, 10, 180)

      // Draw efficiency ratio
      const efficiencyRatio = totalVehicles > 0 ? ((vehiclesPassed / totalVehicles) * 100).toFixed(1) : "0.0"
      ctx.fillText(`Efficiency: ${efficiencyRatio}%`, 10, 200)

      // Draw traffic distribution
      const nsPercentage = totalVehicles > 0 ? Math.round((totalNsVehicles / totalVehicles) * 100) : 0
      const ewPercentage = totalVehicles > 0 ? Math.round((totalEwVehicles / totalVehicles) * 100) : 0
      ctx.fillText(`N/S traffic: ${nsPercentage}%`, 10, 220)
      ctx.fillText(`E/W traffic: ${ewPercentage}%`, 10, 240)

      // Draw congestion indicators
      ctx.fillText(`N/S congestion:`, 10, 260)
      drawCongestionBar(ctx, 110, 255, nsCongestion)

      ctx.fillText(`E/W congestion:`, 10, 280)
      drawCongestionBar(ctx, 110, 275, ewCongestion)
    }

    const drawCongestionBar = (ctx: CanvasRenderingContext2D, x: number, y: number, level: number) => {
      const barWidth = 80
      const barHeight = 8

      // Background
      ctx.fillStyle = "#e5e5e5"
      ctx.fillRect(x, y, barWidth, barHeight)

      // Color based on congestion level
      let barColor
      if (level < 30)
        barColor = "#4ade80" // green
      else if (level < 60)
        barColor = "#facc15" // yellow
      else barColor = "#ef4444" // red

      // Fill bar according to level
      ctx.fillStyle = barColor
      ctx.fillRect(x, y, barWidth * (level / 100), barHeight)

      // Border
      ctx.strokeStyle = "#000"
      ctx.strokeRect(x, y, barWidth, barHeight)

      // Percentage text
      ctx.fillStyle = "black"
      ctx.fillText(`${level}%`, x + barWidth + 5, y + 7)
    }

    // Set initial light timer
    if (lightTimer === 0) {
      setLightTimer(adaptive ? MIN_GREEN_TIME : STATIC_GREEN_TIME)
    }

    // Start or stop animation based on isRunning state
    if (isRunning) {
      animationRef.current = requestAnimationFrame(animate)
    }

    // Initial draw
    const ctx2d = ctx as CanvasRenderingContext2D
    drawScene(ctx2d, canvas.width, canvas.height)

    // Cleanup
    return () => {
      cancelAnimationFrame(animationRef.current)
    }
  }, [
    isRunning,
    vehicles,
    lightState,
    lightTimer,
    adaptive,
    vehiclesPassed,
    waitTime,
    elapsedTime,
    spawnCycle,
    totalVehicles,
    congestionLevel,
    nsCongestion,
    ewCongestion,
    totalNsVehicles,
    totalEwVehicles,
  ])

  return (
    <div className="flex flex-col items-center">
      <div className="relative border border-gray-300 rounded-md overflow-hidden">
        <canvas ref={canvasRef} width={300} height={300} className="bg-gray-100" />
        <div className="absolute top-2 right-2 flex gap-2">
          <Button variant="outline" size="icon" className="w-8 h-8 bg-white" onClick={toggleSimulation}>
            {isRunning ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
          </Button>
          <Button variant="outline" size="icon" className="w-8 h-8 bg-white" onClick={resetSimulation}>
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>
      <div className="mt-4 text-sm">
        <p className="font-medium">{adaptive ? "Adaptive" : "Static (20s)"} Timing</p>
        <p className="text-gray-500">Elapsed: {elapsedTime.toFixed(1)}s</p>

        <div className="mt-3 space-y-2">
          <div className="flex items-center gap-2">
            <div className="text-xs font-medium w-20">N/S Traffic:</div>
            <div className="h-2 w-24 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  nsCongestion < 30 ? "bg-green-500" : nsCongestion < 60 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${nsCongestion}%` }}
              ></div>
            </div>
            <div className="text-xs">{nsCongestion}%</div>
          </div>

          <div className="flex items-center gap-2">
            <div className="text-xs font-medium w-20">E/W Traffic:</div>
            <div className="h-2 w-24 bg-gray-200 rounded-full overflow-hidden">
              <div
                className={`h-full ${
                  ewCongestion < 30 ? "bg-green-500" : ewCongestion < 60 ? "bg-yellow-500" : "bg-red-500"
                }`}
                style={{ width: `${ewCongestion}%` }}
              ></div>
            </div>
            <div className="text-xs">{ewCongestion}%</div>
          </div>
        </div>
      </div>
    </div>
  )
}
